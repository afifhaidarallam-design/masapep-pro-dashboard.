import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const allowedTimeframes = new Set(["M1","M2","M3","M4","M5","M6","M10","M12","M15","M20","M30","H1","H2","H3","H4","H6","H8","H12","D1","W1","MN1"]);
const allowedOrigins = (Deno.env.get("MASAPEP_ALLOWED_ORIGINS") ?? "").split(",").map(v => v.trim()).filter(Boolean);
const corsHeaders = (origin: string | null) => ({
  "Access-Control-Allow-Origin": origin && allowedOrigins.includes(origin) ? origin : (allowedOrigins[0] ?? "https://localhost"),
  "Vary": "Origin",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-ea-token",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Content-Type": "application/json",
});
const json = (body: unknown, status = 200, origin: string | null = null) => new Response(JSON.stringify(body), { status, headers: corsHeaders(origin) });
const isText = (v: unknown, max = 128) => typeof v === "string" && v.trim().length > 0 && v.length <= max;
const isFiniteOptional = (v: unknown) => v == null || (typeof v === "number" && Number.isFinite(v));

async function tokenMatches(expected: string, supplied: string): Promise<boolean> {
  const enc = new TextEncoder();
  const [a, b] = await Promise.all([
    crypto.subtle.digest("SHA-256", enc.encode(expected)),
    crypto.subtle.digest("SHA-256", enc.encode(supplied)),
  ]);
  const aa = new Uint8Array(a), bb = new Uint8Array(b);
  let diff = 0;
  for (let i = 0; i < aa.length; i++) diff |= aa[i] ^ bb[i];
  return diff === 0;
}

Deno.serve(async (req) => {
  const origin = req.headers.get("origin");
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders(origin) });
  if (req.method !== "POST") return json({ error: { code: "METHOD_NOT_ALLOWED", message: "POST required" } }, 405, origin);
  if (origin && allowedOrigins.length && !allowedOrigins.includes(origin)) return json({ error: { code: "ORIGIN_NOT_ALLOWED", message: "Origin not allowed" } }, 403, origin);

  const expected = Deno.env.get("MASAPEP_EA_INGEST_TOKEN");
  const supplied = req.headers.get("x-ea-token") ?? "";
  if (!expected || !supplied || !(await tokenMatches(expected, supplied))) return json({ error: { code: "UNAUTHORIZED", message: "Invalid EA token" } }, 401, origin);
  const contentLength = Number(req.headers.get("content-length") ?? "0");
  if (contentLength > 64_000) return json({ error: { code: "PAYLOAD_TOO_LARGE", message: "Payload exceeds 64 KB" } }, 413, origin);

  let p: any;
  try { p = await req.json(); } catch { return json({ error: { code: "INVALID_JSON", message: "Request body must be JSON" } }, 400, origin); }
  if (!p || typeof p !== "object" || !isText(p.account_login, 64) || !isText(p.instance_name, 64) || !isText(p.symbol, 32) || !p.account || typeof p.account !== "object")
    return json({ error: { code: "INVALID_PAYLOAD", message: "Required telemetry fields are missing" } }, 400, origin);
  const a = p.account;
  for (const key of ["balance","equity","margin","free_margin"]) if (typeof a[key] !== "number" || !Number.isFinite(a[key]) || Math.abs(a[key]) > 1e12)
    return json({ error: { code: "INVALID_ACCOUNT_VALUE", message: `Invalid ${key}` } }, 422, origin);
  for (const key of ["margin_level","floating_pnl","drawdown_pct"]) if (!isFiniteOptional(a[key]))
    return json({ error: { code: "INVALID_ACCOUNT_VALUE", message: `Invalid ${key}` } }, 422, origin);
  const frames = Array.isArray(p.timeframes) ? p.timeframes : [];
  if (frames.length > 21 || frames.some((f: any) => !f || !allowedTimeframes.has(f.timeframe) || !["BULLISH","BEARISH","NEUTRAL","UNKNOWN"].includes(f.trend) || !isFiniteOptional(f.k_value) || !isFiniteOptional(f.d_value)))
    return json({ error: { code: "INVALID_TIMEFRAMES", message: "Timeframe payload is invalid" } }, 422, origin);

  const url = Deno.env.get("SUPABASE_URL"), key = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!url || !key) return json({ error: { code: "SERVER_NOT_CONFIGURED", message: "Telemetry service is not configured" } }, 503, origin);
  const db = createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
  const accountLogin = String(p.account_login), symbol = String(p.symbol);
  const instance = { account_login: accountLogin, broker: isText(p.broker, 100) ? p.broker : null, account_currency: isText(a.currency, 8) ? a.currency : "USD", terminal_name: isText(p.terminal_name, 100) ? p.terminal_name : null, instance_name: String(p.instance_name), status: "active", last_seen_at: new Date().toISOString() };
  const { data: row, error: instanceError } = await db.from("mt5_instances").upsert(instance, { onConflict: "account_login,instance_name" }).select("id").single();
  if (instanceError || !row) return json({ error: { code: "INSTANCE_WRITE_FAILED", message: "Could not register EA instance" } }, 500, origin);
  const instanceId = row.id;
  const { error: hbError } = await db.from("ea_heartbeat").insert({ instance_id: instanceId, account_login: accountLogin, symbol, ea_version: isText(p.ea_version, 32) ? p.ea_version : null, terminal_connected: p.terminal_connected === true, trading_allowed: p.trading_allowed === true, server_time: p.server_time ?? null });
  if (hbError) return json({ error: { code: "HEARTBEAT_WRITE_FAILED", message: "Could not save EA heartbeat" } }, 500, origin);
  const { error: snapError } = await db.from("account_snapshots").insert({ instance_id: instanceId, account_login: accountLogin, currency: instance.account_currency, balance: a.balance, equity: a.equity, margin: a.margin, free_margin: a.free_margin, margin_level: a.margin_level ?? null, floating_pnl: a.floating_pnl ?? 0, drawdown_pct: a.drawdown_pct ?? null });
  if (snapError) return json({ error: { code: "SNAPSHOT_WRITE_FAILED", message: "Could not save account snapshot" } }, 500, origin);
  if (frames.length) {
    const rows = frames.map((f: any) => ({ instance_id: instanceId, account_login: accountLogin, symbol, timeframe: f.timeframe, trend: f.trend, k_value: f.k_value ?? null, d_value: f.d_value ?? null, candle_time: f.candle_time ?? null }));
    const { error } = await db.from("timeframe_snapshots").upsert(rows, { onConflict: "instance_id,symbol,timeframe,candle_time" });
    if (error) return json({ error: { code: "TIMEFRAME_WRITE_FAILED", message: "Could not save timeframe snapshots" } }, 500, origin);
  }
  return json({ ok: true, instance_id: instanceId, accepted_timeframes: frames.length, received_at: new Date().toISOString() }, 200, origin);
});
