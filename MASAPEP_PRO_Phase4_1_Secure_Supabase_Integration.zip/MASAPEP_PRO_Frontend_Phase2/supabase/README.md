# MASAPEP PRO — Supabase telemetry foundation

This is the backend foundation only. It does not connect or execute trades by itself.

## 1. Database
Apply `migrations/202611210001_masapep_core.sql` in the Supabase SQL Editor. It creates the telemetry tables and authenticated read-only RLS policies. EA writes are accepted only by the Edge Function using a server-side service-role key.

## 2. Edge Function secrets
Deploy `mt5-telemetry` and set secrets on the Supabase project:

- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY` (server-side only)
- `MASAPEP_EA_INGEST_TOKEN` (long random token shared privately with the EA)

Never put either secret in Netlify `VITE_` variables, frontend source, GitHub, screenshots or chat.

## 3. Endpoint contract
POST `/functions/v1/mt5-telemetry`, header `x-ea-token`, JSON body:

```json
{
  "account_login":"demo-account-id",
  "broker":"Broker name",
  "instance_name":"PC-PRIMARY",
  "terminal_name":"MetaTrader 5",
  "ea_version":"V3.09",
  "symbol":"XAUUSD",
  "terminal_connected":true,
  "trading_allowed":true,
  "server_time":"2026-11-21T02:00:00Z",
  "account":{"currency":"USD","balance":1000,"equity":1005,"margin":20,"free_margin":985,"margin_level":5025,"floating_pnl":5,"drawdown_pct":0.2},
  "timeframes":[{"timeframe":"M1","trend":"BULLISH","k_value":62.1,"d_value":55.2,"candle_time":"2026-11-21T02:00:00Z"}]
}
```

The function validates the request and writes instance heartbeat, account snapshot and timeframe snapshots. The current EA source is not yet patched to send this payload. Only timeframe values actually emitted by EA should be shown as live. Annual Y1 is derived from trusted MN1 history; it is not an MT5-native timeframe.

## 4. Before enabling production
- Add the Supabase Edge Function URL to MT5 WebRequest allowlist.
- Add a dedicated, revocable EA ingest token to EA inputs (do not reuse Telegram token).
- Patch EA telemetry additively, with bounded timeout and rate limiting; no trade logic changes.
- Add command queue claim/ack flow separately; this ingestion endpoint does not execute commands.
- Implement single-executor lease before running both PC and VPS.
- Test only on demo account first.

## 5. Secure account access (required)
Apply `migrations/202611210002_account_scoped_rls.sql` AFTER the core migration. This replaces broad authenticated-read policies with account membership checks. Browser users cannot grant themselves access or write telemetry.

After creating the first dashboard user in Supabase Authentication, add that user's UUID and MT5 account login using the SQL Editor (replace both placeholders):

```sql
insert into public.account_members (user_id, account_login, access_role)
select id, 'YOUR_MT5_ACCOUNT_LOGIN', 'owner'
from auth.users
where email = 'YOUR_LOGIN_EMAIL'
on conflict (user_id, account_login) do nothing;
```

Do not share the account login publicly if it is sensitive. The SQL Editor is an admin surface; run this only for the intended account owner. Verify the row exists before signing in to the dashboard.

## 6. Edge Function deployment
Set `MASAPEP_ALLOWED_ORIGINS` to the exact Netlify site origin(s), comma-separated, for example `https://your-site.netlify.app`. Set `MASAPEP_EA_INGEST_TOKEN` to a long random token generated privately. Keep `SUPABASE_SERVICE_ROLE_KEY` only as a Supabase Edge Function secret. Deploy `mt5-telemetry` after setting secrets.

This endpoint currently ingests instance heartbeat, account snapshots and timeframe snapshots. It does NOT ingest positions/trade history, issue commands, or enforce PC/VPS executor leases. Those remain separate phases. EA V3.09 has not been modified and cannot send telemetry until a reviewed additive patch is made.
