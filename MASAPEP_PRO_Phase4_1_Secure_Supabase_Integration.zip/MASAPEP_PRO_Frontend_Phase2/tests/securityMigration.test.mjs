import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const migration = readFileSync(new URL('../supabase/migrations/202611210002_account_scoped_rls.sql', import.meta.url), 'utf8');
const edge = readFileSync(new URL('../supabase/functions/mt5-telemetry/index.ts', import.meta.url), 'utf8');

test('RLS scopes account data to explicit account membership', () => {
  assert.match(migration, /create table if not exists public\.account_members/i);
  assert.match(migration, /am\.user_id = auth\.uid\(\).*am\.account_login = account_snapshots\.account_login/s);
  assert.doesNotMatch(migration, /using\s*\(true\)/i);
});

test('browser roles cannot write telemetry or membership grants', () => {
  assert.match(migration, /revoke insert, update, delete[\s\S]*from anon, authenticated/i);
});

test('EA ingestion validates token and bounds payload size', () => {
  assert.match(edge, /tokenMatches\(expected, supplied\)/);
  assert.match(edge, /contentLength > 64_000/);
  assert.match(edge, /INVALID_TIMEFRAMES/);
});

test('service role remains server-side and errors do not expose database details', () => {
  assert.match(edge, /Deno\.env\.get\("SUPABASE_SERVICE_ROLE_KEY"\)/);
  assert.doesNotMatch(edge, /detail:\s*instanceError\?\.message/);
});
